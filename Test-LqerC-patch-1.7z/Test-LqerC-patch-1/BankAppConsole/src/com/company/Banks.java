package com.company;

import java.io.IOException;

public class Banks {

    public static void main(String[] args) throws IOException, ClassNotFoundException {
        LogIn loger = new LogIn();
        loger.Login();
    }
}
