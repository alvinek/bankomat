package com.company;

import java.io.Serializable;

class UsersInfo implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = 1L;
    String userName;
    String userpassword = "";

    private double userBalance = 100.0;

    public void minusUserPayment(double payoff) {
        if (this.userBalance < payoff || payoff <= 0) {
            System.out.println("Not enough funds on balance or not correct withdraw sum ");
        } else {
            this.userBalance = this.userBalance - payoff;
            System.out.println(" " + payoff);
        }

    }
    /*
     * every user'll save in Dat file "username.dat"+i.ToString();
     */

    public double getUserBalance() {
        return userBalance;
    }

    public void setUserBalance(double payment) {
        if (payment > 0) {
            this.userBalance = this.userBalance + payment;

        } else {
            System.out.println("Wrong value");
        }

    }

    public void setUserpassword(String userpassword) {
        this.userpassword = userpassword;
        System.out.println("Password has been set");
    }

    public UsersInfo(String userName) {
        this.userName = userName;

    }

    public UsersInfo() {
    }
}
