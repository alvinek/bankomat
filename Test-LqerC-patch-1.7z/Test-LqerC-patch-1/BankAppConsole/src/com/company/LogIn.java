package com.company;

import java.io.*;
import java.util.Scanner;

public class LogIn {

    String name;
    String password;
    Scanner scan = new Scanner(System.in);
    Scanner scanForString = new Scanner(System.in);

    public void Login() throws IOException, ClassNotFoundException {
        System.out.println(" \t****Hello,Welcome to the BankAPP****\n");
        System.out.println("Please introduce yourself");
        name = scan.nextLine();

        System.out.println("Hello Please Login or Sign up;");
        System.out.println("1.Press 1 to Log In");
        System.out.println("2.Press 2 to Sign Up");

        int switchCheck = 0;

        boolean isGood = false;
        Scanner scanlog = new Scanner(System.in);
        do {
            System.out.print("");
            if (scanlog.hasNextInt()) {
                switchCheck = scanlog.nextInt();
                isGood = true;
            } else {
                scanlog.next();
                System.out.println("Choose the numeric options please...");
            }
        } while (!isGood);

        
            if (switchCheck == 1 || switchCheck == 2) {

                switch (switchCheck) {
                case 1:
                    Logs();
                    break;
                case 2:
                    Signs(name);
                    break;
                }
            } else {
                System.out.println("No such option");
                Login();
            }
        
        scanlog.close();
        scan.close();
    }

    private void Logs() throws IOException, ClassNotFoundException {
        UsersInfo restoredUser;
        try (ObjectInputStream objectInputStream = new ObjectInputStream(new FileInputStream(name))) {
            restoredUser = (UsersInfo) objectInputStream.readObject();

            System.out.println("Hello " + restoredUser.userName);
            if (restoredUser.userpassword.equals("")) {
                System.out.println("Access granted,thank you \t");
                Menu mainMenu = new Menu(restoredUser);
            } else {
                System.out.println("Please enter your password \t");
                String checkpass = scanForString.nextLine();
                if (checkpass.equals(restoredUser.userpassword)) 
                {
                    System.out.println("Access granted,thank you \t");
                    Menu mainMenu = new Menu(restoredUser);
                } else {
                    System.out.println("Access denied.Check the corectness of password \t");
                    Login();
                }
            }
        } catch (IOException e) {
            System.out.println("No such user exists!");
            Login();
        }
    }

    private void Signs(String name) throws IOException, ClassNotFoundException {
        UsersInfo NewUser = new UsersInfo(name);

        try (ObjectOutputStream objectOutputStream = new ObjectOutputStream(new FileOutputStream(name))) {
            objectOutputStream.writeObject(NewUser);
        }
        System.out.println("Succesfully registered!Congratulations , you are a member of BankApp");
        System.out.println("100$ credit granted for registration");
        Menu mainMenu = new Menu(NewUser);
    }

    public static void Signs(UsersInfo obj) throws IOException, ClassNotFoundException {   //to save user account status;

        try (ObjectOutputStream objectOutputStream = new ObjectOutputStream(new FileOutputStream(obj.userName))) {
            objectOutputStream.writeObject(obj);
        }
        System.out.println("Ty for using BankApp!");
    }
}
