package com.company;

import java.io.IOException;
import java.util.Scanner;

public class Menu {
    public Menu(UsersInfo obj) throws ClassNotFoundException, IOException {
        MainMenu(obj);
    }

    boolean cont = false;

    public void MainMenu(UsersInfo obj) throws ClassNotFoundException, IOException {

        System.out.println("What we can do for u?");
        System.out.println("1. Check Balance");
        System.out.println("2. Withraw Money");
        System.out.println("3. Add Funds to your account");
        System.out.println("4. Set password");
        System.out.println("5. Exit");
        double switchLocal = 0.00;
        boolean boolCheckMenu = false;
        Scanner scan = new Scanner(System.in);
        Scanner scanForString = new Scanner(System.in);
        int menuchoice = 0;
        while (!boolCheckMenu) {
            System.out.print("");
            if (scan.hasNextInt()) {
                menuchoice = scan.nextInt();
                boolCheckMenu = true;

            } else {

                scan.nextLine();
                System.out.println("Choose one of the options please...");
            }
        }

        switch (menuchoice) {
        case 1:
            System.out.println("Your balance is : " + obj.getUserBalance());
            break;
        case 2:

            boolCheckMenu = false;

            while (!boolCheckMenu) {
                System.out.print("Enter value for withdraw \n");
                if (scan.hasNextDouble()) {
                    switchLocal = scan.nextDouble();
                    boolCheckMenu = true;

                } else {

                    scan.nextLine();
                    System.out.println("Enter the numeric value\n");
                }
            }
            System.out.println("U have withrawed : \t");
            obj.minusUserPayment(switchLocal);
            break;
        case 3:
            boolCheckMenu = false;

            while (!boolCheckMenu) {
                System.out.print("Enter payment for adding funds on your account \n");
                if (scan.hasNextDouble()) {
                    switchLocal = scan.nextDouble();
                    boolCheckMenu = true;

                } else {

                    scan.nextLine();
                    System.out.println("Enter the correct numeric value\n");
                }
            }
            System.out.println("U have payed in: \t" + switchLocal);
            obj.setUserBalance(switchLocal);
            break;

        case 4:
            System.out.print("Please enter your password \t");
            obj.setUserpassword(scanForString.nextLine());
            break;

        case 5:
            System.out.println("\t ***Goodbye!*** \n");
            LogIn.Signs(obj);
            cont = true;
            break;

        default:
            System.out.println("\t ***No such option*** \n");
            break;
        }

        if (!cont) {
            MainMenu(obj);
        }
        
        scan.close();
        scanForString.close();
    }
}
